import java.util.Scanner;

class Enkapulasi{
	Scanner input = new Scanner(System.in);

	private String nama;
	private char merek,tipe;
	private int kembalian,totalharga,bayar,jumlah;
	private int harga = 0;	
	private boolean loop = true;

	public void setNama(String nama ){
		this.nama = nama;
	
	}

	public String getNama(){
		return nama;
	}
	
	
		public void pilihan(){
		
		while (loop){
		System.out.println("	 MERK		|    TIPE	|   HARGA");
		System.out.println("	  G		| Meja  (M)	| Rp. 95000");
		System.out.println("			| Kursi (K)	| Rp.125000");
		System.out.println("			| Lemari(L)	| Rp.450000");
		System.out.println("----------------------------------------------------");
		System.out.println("  	  O		| Meja  (M)	| Rp.115000");
		System.out.println("			| Kursi (K)	| Rp.135000");
		System.out.println("			| Lemari(L)	| Rp.550000");
		System.out.print("Merek: ");
        merek= input.next().charAt(0);
       
	 	if(merek == 'G' || merek == 'g'){
        	while(loop){
        		
        		
        		System.out.print("Masukkan Tipe nya: ");
                tipe= input.next().charAt(0);
                
        	switch(tipe){
        	case 'm':
            case 'M':
                harga = 95000;
                System.out.println("Harga/pcs: "+harga);
                loop = false;
                break;
            case 'k':
            case 'K':
               			harga = 125000;
                 		System.out.println("Harga/pcs:" +harga);
                 		loop = false;
                break;
            case 'l':   
            case 'L':
               			harga = 450000;
                		System.out.println("Harga/pcs:" +harga);
                 		loop = false;
                		break;
            default :
                System.out.println("Tipe Tidak Ditemukan");
                break;
        	}
        	
        }
    }
    else if(merek =='O' || merek=='o'){
    	
    	while(loop){
    		System.out.print("Tipe: ");
                tipe= input.next().charAt(0);
    	switch(tipe){
    		case 'm':
            case 'M':
                		harga = 115000;
                		System.out.println("Harga/pcs: "+harga);
                		loop = false;
                		break;
            case 'k':
            case 'K':
               			harga = 135000;
                	 	System.out.println("Harga/pcs:" +harga);
                 		loop = false;
                		break;
            case 'L':
            case 'l':
               			harga = 550000;
                 		System.out.println("Harga/pcs:" +harga);
                 		loop = false;
                		break;
            default :
                System.out.println("Tipe Tidak Ditemukan");
                break;
    	}
    		
    	
    }
   	}else{
		
		System.out.println("Merk Tidak Ditemukan");
	}
	
  }
}

	public void pembayaran(){

		System.out.print("Jumlah: ");
        jumlah = input.nextInt();
    	totalharga = jumlah*harga;
    	
    	System.out.println("==========INVOICE==========");
    	System.out.println();
    	System.out.println("Total Harga: "+totalharga);
    	System.out.println("");
    	System.out.print("Bayar: "+"Rp.");
		bayar= input.nextInt();
			
			
		while(bayar<totalharga){
			
			if(bayar<totalharga){
				System.out.println("Nominal Uang Kurang, Mohon Tambahkan");
				
	            System.out.print("Bayar: "+"Rp. ");
		    
		        bayar= input.nextInt();
			
				}
				else{
			
				System.out.print("Bayar: "+"Rp. ");
		    
		        bayar= input.nextInt();
			
				}	
}

	
}

 	public void cetak()
 	{
		System.out.println("");
		System.out.println("=====PEMBAYARAN SELESAI=====");
		System.out.println("Nama pelanggan : " +nama);
		System.out.println("Total harga    : " +totalharga);
		System.out.println("Pembayaran     : " +bayar);
		System.out.println("Kembaliaan     : " +(bayar-totalharga));
	}
	
	
}
