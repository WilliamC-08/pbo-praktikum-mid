import java.util.Scanner;
import java.util.Date;  
import java.text.DateFormat;  
import java.text.SimpleDateFormat; 

public class Proses extends Pesan
{ 	private int bayar;
	private int harga;
	private char merek;
	private int tipe;
	private int total;
	private int banyak;
    
	public Proses(String nama, String alamat ){
		
		super(nama,alamat);
		this.bayar = bayar;	
		this.harga = harga;
		this.merek = merek;
		this.tipe = tipe;
		this.total = total;
		this.banyak = banyak;
	}

	public int getBayar(){
		return bayar;
	}
	public int getHarga(){
		return harga;
	}
	public char getMerek(){
		return merek;
	}
	public int getBanyak(){
		return banyak;
	}
	public int getTipe(){
		return tipe;
	}
	public int getTotal(){
		return total;
	}
	public String getWaktu() {  
        DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");  
        Date date = new Date();  
        return dateFormat.format(date);  
    }
    
    public String getTanggal() {  
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");  
        Date date = new Date();  
        return dateFormat.format(date);  
    }
	

	public void pilihan(){
		
		Scanner input = new Scanner(System.in);
		boolean loop=true;
		
		System.out.println("	 MERK		|    TIPE	|   HARGA");
		System.out.println("	  G		| Meja  (M)	| Rp. 95000");
		System.out.println("			| Kursi (K)	| Rp.125000");
		System.out.println("			| Lemari(L)	| Rp.450000");
		System.out.println("----------------------------------------------------");
		System.out.println("  	  O		| Meja  (M)	| Rp.115000");
		System.out.println("			| Kursi (K)	| Rp.135000");
		System.out.println("			| Lemari(L)	| Rp.550000");
		System.out.println("");
		
		System.out.print("Masukkan Merek : ");
		merek = input.next().charAt(0);
		while(loop){
		System.out.print("Masukkan tipe : ");
		
        tipe = input.next().charAt(0);
		

		 switch(tipe)
		 {
		 	case 'm' :
            case 'M' :
               if (merek =='G' ||merek =='g' )
               {harga = 95000;
               }
               else {harga = 115000;
               }
                loop = false;
                break;
          
           case 'k' :     
           case 'K' :
               if (merek =='G' ||merek =='g') 
               {harga = 125000;
               }
               else {harga = 135000;
               }
                loop = false;
                break;

	 	   case 'l' :
           case 'L' :
               if (merek =='G' ||merek =='g') 
               {harga = 450000;
               }
               else {harga = 550000;
               }
                loop = false;
                break;

               default :
                System.out.println("Pilihan tidak tersedia, mohon input ulang");
               
                
        }
        
	  
	}
	
       System.out.print("Masukkan Banyak Pesanan : ");
       banyak = input.nextInt();
       total = banyak*harga;
       System.out.println("Total Harga   : Rp. "+total);
}	
	public void pembayaran()
	{
		Scanner input = new Scanner(System.in);
    	
    	System.out.print("Masukkan Jumlah uang dibayarkan : "+"Rp.");
		bayar= input.nextInt();
			
			
		while(bayar<total){
			
			if(bayar<total){
				System.out.println("uang anda kurang mohon masukkan dengan nominal yang lebih besar");
				
	            System.out.print("Masukkan Jumlah uang dibayarkan : "+"Rp.");
		        bayar= input.nextInt();
			
				}
				else{
					System.out.print("Masukkan Jumlah uang dibayarkan : "+"Rp.");
		        bayar= input.nextInt();
				}
	
		
		}
	}
		
}
